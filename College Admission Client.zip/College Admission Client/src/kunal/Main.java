package kunal;

/**
 * Created by kunal on 08-09-2017.
 */
public class Main {
    public static void main(String args[])
    {
        Student s=new Student();
        s.getDetails();
        s.sendDetails();
    }
}
