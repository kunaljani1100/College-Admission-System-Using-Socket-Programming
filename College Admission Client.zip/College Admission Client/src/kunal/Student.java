package kunal;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Created by kunal on 08-09-2017.
 */
public class Student {
    Scanner scanner = new Scanner(System.in);
    private String ID;
    private String firstName;
    private String middleName;
    private String lastName;
    private int phyMarks;
    private int chemMarks;
    private int mathMarks;
    private int totalMarks;
    private int[] listOfPreferences = new int[5];

    private void calcTotalMarks() {
        this.totalMarks = this.phyMarks + this.chemMarks + this.mathMarks;
    }

    public void getDetails() {
        try {
            System.out.println("Enter identity number:");
            ID=scanner.nextLine();
            System.out.println("Enter first name:");
            firstName = scanner.nextLine();
            System.out.println("Enter middle name:");
            middleName = scanner.nextLine();
            System.out.println("Enter last name:");
            lastName = scanner.nextLine();
            System.out.println("Enter physics marks:");
            phyMarks = scanner.nextInt();
            System.out.println("Enter chemistry marks:");
            chemMarks = scanner.nextInt();
            System.out.println("Enter mathematics marks:");
            mathMarks = scanner.nextInt();
            calcTotalMarks();
        }
        catch (InputMismatchException e)
        {
            System.out.println("You have not entered a proper value.");
            System.exit(-1);
        }
    }

    public void sendDetails()
    {
        try
        {
            Socket socket = new Socket("localhost", 600);
            PrintWriter sendResult = new PrintWriter(socket.getOutputStream(), true);
            sendResult.println(ID);
            sendResult.println(firstName);
            sendResult.println(middleName);
            sendResult.println(lastName);
            sendResult.println(Integer.toString(totalMarks));
            int choice = 0;
            int i = 0;
            for (int k = 0; k < 5; k++)
            {
                listOfPreferences[k] = -1;
            }
            i=0;
            while (choice != 6 && i<5)
            {
                System.out.println("Enter your preference:");
                System.out.println("0.College 1");
                System.out.println("1.College 2");
                System.out.println("2.College 3");
                System.out.println("3.College 4");
                System.out.println("4.College 5");
                System.out.println("5.Exit");
                choice = scanner.nextInt();
                if (choice == 5)
                {
                    break;
                }
                listOfPreferences[choice] = i+1;
                i++;
            }
            sendResult.println(Integer.toString(listOfPreferences[0]));
            sendResult.println(Integer.toString(listOfPreferences[1]));
            sendResult.println(Integer.toString(listOfPreferences[2]));
            sendResult.println(Integer.toString(listOfPreferences[3]));
            sendResult.println(Integer.toString(listOfPreferences[4]));
        }
        catch (SocketException e)
        {
            //System.out.println("Socket error.");
            e.printStackTrace();
        }
        catch (IOException e)
        {
            //System.out.println("Error.");
            e.printStackTrace();
        }
    }
}