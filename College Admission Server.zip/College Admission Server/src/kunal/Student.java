package kunal;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

/**
 * Created by kunal on 08-09-2017.
 */
public class Student
{
    private String ID;
    private String firstName;
    private String middleName;
    private String lastName;
    private int totalMarks;
    private int []listOfPreferences=new int[5];
    public Student()
    {

    }
    public Student(String ID,String firstName,String middleName,String lastName,int totalMarks,int []list)
    {
        this.ID=ID;
        this.firstName=firstName;
        this.middleName=middleName;
        this.lastName=lastName;
        this.totalMarks=totalMarks;
        this.listOfPreferences=list;
    }
    public void receiveResult()
    {
        try
        {
            ServerSocket serverSocket1=new ServerSocket(600);
            Socket socket=serverSocket1.accept();
            System.out.println("Client connected.");
            BufferedReader resultReader=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            ID=resultReader.readLine();
            firstName=resultReader.readLine();
            middleName=resultReader.readLine();
            lastName=resultReader.readLine();
            totalMarks=Integer.parseInt(resultReader.readLine());
            listOfPreferences[0] = Integer.parseInt(resultReader.readLine());
            listOfPreferences[1] = Integer.parseInt(resultReader.readLine());
            listOfPreferences[2] = Integer.parseInt(resultReader.readLine());
            listOfPreferences[3] = Integer.parseInt(resultReader.readLine());
            listOfPreferences[4] = Integer.parseInt(resultReader.readLine());
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        try
        {
            BufferedWriter writer=new BufferedWriter(new FileWriter(ID+".txt",true));
            BufferedWriter listWriter=new BufferedWriter(new FileWriter("list.txt",true));
            listWriter.write(ID+"\n");
            listWriter.close();
            writer.write(ID+"\n");
            writer.write(firstName+"\n");
            writer.write(middleName+"\n");
            writer.write(lastName+"\n");
            writer.write(Integer.toString(totalMarks)+"\n");
            for(int x=0;x<5;x++)
            {
                writer.write(Integer.toString(listOfPreferences[x])+"\n");
            }
            writer.close();
        }
        catch (SocketException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
    public String getID()
    {
        return ID;
    }
    public String getFirstName()
    {
        return firstName;
    }
    public String getLastName()
    {
        return lastName;
    }
    public String getMiddleName()
    {
        return middleName;
    }
    public int [] getListOfPreferences()
    {
        return listOfPreferences;
    }
    public int getTotalMarks()
    {
        return totalMarks;
    }
}
