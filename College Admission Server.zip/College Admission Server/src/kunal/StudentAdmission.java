package kunal;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by kunal on 08-09-2017.
 */
public class StudentAdmission
{
    private String ID;
    private String listID="";
    private String firstName;
    private String middleName;
    private String lastName;
    private int totalMarks;
    private int []listOfPreferences=new int[5];
    Student [][]list=new Student[5][10];
    public void giveAdmissionResult()
    {
        int []m=new int[10];
        for(int z=0;z<10;z++)
        {
            m[z]=0;
        }
        try
        {
            BufferedReader reader=new BufferedReader(new FileReader("list.txt"));
            boolean flag=false;
            while(listID!=null)
            {
                listID=reader.readLine();
                if(listID==null)
                {
                    break;
                }
                BufferedReader IDreader=new BufferedReader(new FileReader(listID+".txt"));
                ID=IDreader.readLine();
                firstName=IDreader.readLine();
                middleName=IDreader.readLine();
                lastName=IDreader.readLine();
                totalMarks=Integer.parseInt(IDreader.readLine());
                listOfPreferences[0]=Integer.parseInt(IDreader.readLine());
                listOfPreferences[1]=Integer.parseInt(IDreader.readLine());
                listOfPreferences[2]=Integer.parseInt(IDreader.readLine());
                listOfPreferences[3]=Integer.parseInt(IDreader.readLine());
                listOfPreferences[4]=Integer.parseInt(IDreader.readLine());
                Student student=new Student(ID,firstName,middleName,lastName,totalMarks,listOfPreferences);
                int currentPreference=1;
                while(currentPreference<=5)
                {
                    if(flag)
                    {
                        break;
                    }
                    for(int i=0;i<5;i++)
                    {
                        if(listOfPreferences[i]==currentPreference)
                        {
                            if(m[i]<10)
                            {
                                list[i][0] = student;
                                m[i]++;
                                flag=true;
                            }
                            for(int x=0;x<m[i];x++)
                            {
                                for(int y=0;y<m[i]-1;y++)
                                {
                                    if(list[i][y].getTotalMarks()>list[i][y+1].getTotalMarks())
                                    {
                                        Student tmp=list[i][y];
                                        list[i][y]=list[i][y+1];
                                        list[i][y+1]=tmp;
                                    }
                                }
                            }
                            for(int j=0;j<m[i];j++)
                            {
                                if(student.getTotalMarks()>list[i][j].getTotalMarks())
                                {
                                    for(int k=m[i]-1;k>j;k--)
                                    {
                                        list[i][k]=list[i][k-1];
                                    }
                                }
                            }
                        }
                    }
                    currentPreference++;
                }
            }
            for(int i=0;i<5;i++)
            {
                System.out.println("College "+i);
                for(int j=0;j<m[i];j++)
                {
                    System.out.println(list[i][j].getID()+"\n");
                }
                System.out.println("\n");
            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
}
