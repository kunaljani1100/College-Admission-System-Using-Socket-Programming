package kunal;

public class Main {

    public static void main(String[] args) {
        StudentAdmission admission=new StudentAdmission();
        admission.giveAdmissionResult();
    }
}
